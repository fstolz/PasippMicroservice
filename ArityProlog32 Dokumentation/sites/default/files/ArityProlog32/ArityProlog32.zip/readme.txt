Arity/Prolog32

For documentation, please visit http://peter-gabel.com. 

Tools for linking compiled Arity/Prolog32 applications are available at http://masm32.com.


